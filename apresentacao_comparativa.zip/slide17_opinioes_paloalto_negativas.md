# Opiniões dos Clientes - Palo Alto Cortex XDR
## Principais Críticas

### Interface e Usabilidade
> "A interface pode ser intimidante e requer equipe de TI com conhecimento."

> "Preocupações sobre falsos positivos e problemas de usabilidade com a interface do console."

> "Necessidade de ajuste para evitar sobrecarga de alertas."

### Carga de Trabalho e Ajustes
> "Aumento da carga de trabalho para equipes de segurança de endpoint."

> "Coloca mais trabalho no endpoint em comparação com um servidor local."

> "Requer ajustes significativos em ambientes com software personalizado."

### Suporte ao Cliente
> "O serviço ao cliente é o pior aspecto da Palo Alto, sendo uma empresa tão grande que não está disposta a ouvir os problemas dos clientes."

> "Encontrou bugs em versões mais antigas do agente."

> "Melhor para ambientes de TI usando relatórios/dashboards COTS."
