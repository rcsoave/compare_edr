# Preço e Licenciamento

## SentinelOne Protection Platform
- **Modelo de Licenciamento**: 
  - Por endpoint, com cinco níveis de serviço
  - Core: $69,99 por endpoint
  - Control: $79,99 por endpoint
  - Complete: $179,99 por endpoint
  - Commercial: $229,99 por endpoint
  - Enterprise: Preço sob consulta

## Palo Alto Cortex XDR Pro
- **Modelo de Licenciamento**:
  - Múltiplos modelos: por endpoint, por host na nuvem, por GB
  - Cortex XDR Prevent
  - Cortex XDR Pro per Endpoint
  - Cortex XDR Cloud per Host
  - Cortex XDR Pro per GB

## Opinião dos Clientes
- SentinelOne: "Preço um pouco elevado, mas vale o investimento"
- Palo Alto: "Menos caro que um servidor local, mas coloca mais trabalho no endpoint"
