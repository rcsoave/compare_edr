# Opiniões dos Clientes - SentinelOne
## Principais Críticas

### Custo
> "Preço um pouco elevado, mas vale o investimento."

> "Organizações com orçamentos limitados ou equipes de segurança menores podem achar os custos proibitivos."

> "Mais caro quando se deseja a suíte completa de recursos que tornam a plataforma mais eficaz."

### Configuração e Implementação
> "Configuração inicial e personalização requerem investimento de tempo considerável."

> "Necessidade de ajuste fino para otimizar o desempenho."

> "Curva de aprendizado para novos usuários."

### Recursos Avançados
> "Recursos avançados de proteção de identidade disponíveis apenas nos pacotes superiores."

> "Algumas funcionalidades dependem de processamento em nuvem."

> "Documentação detalhada para implantação local é limitada."
